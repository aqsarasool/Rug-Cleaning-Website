<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from azim.commonsupport.com/Uthan/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 26 Jul 2023 06:57:11 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
 <meta name="description" content="We provide best carpet cleaning, area rug, and upholstery cleaning in Bronx. We also provide 
    same day service. Call today to get your FREE estimate!" />
    <meta name="keywords" content="carpet cleaning, carpet cleaners, cleaning services, cleaning services in Bronx, cleaning service
     in Bronx, carpet installation Bronx, carpet installation in Bronx, area rug cleaning Bronx, area rug cleaners in 
     Bronx, area rug repair in Bronx, mattress cleaning services, mattress cleaner Bronx, mattress cleaners Bronx, Bronx
      carpet cleaning, Bronx carpet cleaners, Bronx carpet installation, Bronx carpet installer, Bronx organic cleaning
       services, Bronx organic cleaner services, Bronx organic cleaners services, rug cleaning, rug cleaners, Bronx rug cleaning,
        Bronx rug cleaners, rug cleaning in Bronx, rug cleaners in Bronx, commercial carpet cleaning, commercial carpiting cleaning
         Bronx, Bronx commercial carpet cleaning, upholstery cleaning, upholstery cleaning Bronx, upholstery cleaners in Bronx,
          Bronx upholstery cleaning, Bronx upholstery cleaners, bed bug treatment, bed bug treatment Bronx, Bronx bed bug treatment,
           stain removal, stain removal Bronx, Bronx stain removal, pet Odor cleaning, pet Odor cleaning Bronx, Bronx pet Odor cleaners,
            pet Odor cleaners Bronx, pet Odor cleaners, mattress cleaning, mattress cleaning Bronx, mattress cleaning in Bronx, Bronx 
            mattress cleaning, Bronx mattress cleaners, water damage, water damage services in Bronx, water damage services Bronx, Bronx
             water damage services, water damage services in Bronx, Area Rug Cleaning Bronx, area rug 
             cleaning Bronx, Area Rug Cleaning Bronx , Area Rug Cleaning Bronx, Carpet Cleaning Bronx, Carpet Cleaning 
             Bronx,">
<title>Rug Clean Bronx | Area Rug Cleaning | Carpet Cleaning Services | 20% Off in Cleaning Services</title>

<!-- Fav Icon -->
<link rel="icon" href="assets/images/logo/Favicon.png" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Prata&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="assets/css/font-awesome-all.css" rel="stylesheet">
<link href="assets/css/flaticon.css" rel="stylesheet">
<link href="assets/css/owl.css" rel="stylesheet">
<link href="assets/css/bootstrap.css" rel="stylesheet">
<link href="assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="assets/css/animate.css" rel="stylesheet">
<link href="assets/css/color.css" rel="stylesheet">
<link href="assets/css/elpath.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
<link href="assets/css/responsive.css" rel="stylesheet">

</head>
<?php
 $area = $_GET['area'];
if ($area == "" || $area == "Bronx") {

    $area = "Bronx";
} else {

    $area = $_GET['area'];
}
?>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper">


        <!-- preloader -->
        <div class="loader-wrap">
            <div class="preloader">
                <div class="preloader-close">x</div>
                <div id="handle-preloader" class="handle-preloader">
                    <div class="animation-preloader">
                        <div class="spinner"></div>
                        <div class="txt-loading">
                            <span data-text-preloader="r" class="letters-loading">
                                r
                            </span>
                              <span data-text-preloader="u" class="letters-loading">
                               u
                            </span>
                            <span data-text-preloader="g" class="letters-loading">
                               g
                            </span>
                            <span data-text-preloader="" class="letters-loading">
                                <div class="space1"></div>
                            </span>
                        <span data-text-preloader="c" class="letters-loading">
                                c
                            </span>
                            <span data-text-preloader="l" class="letters-loading">
                                l
                            </span>
                            <span data-text-preloader="e" class="letters-loading">
                                e
                            </span>
                            <span data-text-preloader="a" class="letters-loading">
                                a
                            </span>
                            <span data-text-preloader="n" class="letters-loading">
                                n
                            </span>
                            <span data-text-preloader="" class="letters-loading">
                                <div class="space1"></div>
                            </span>
                            <span data-text-preloader="b" class="letters-loading">
                                b
                            </span>
                         <span data-text-preloader="r" class="letters-loading">
                                r
                            </span>
                            <span data-text-preloader="o" class="letters-loading">
                                o
                            </span>
                            <span data-text-preloader="n" class="letters-loading">
                                n
                            </span>
                            <span data-text-preloader="x" class="letters-loading">
                                x
                            </span>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
        <!-- preloader end -->


        <!-- main header -->
        <header class="main-header">
            <!-- header-top -->
            <div class="header-top">
                <div class="shape" style="background-image: url(assets/images/shape/shape-16.png);"></div>
                <div class="auto-container">
                    <div class="top-inner clearfix">
                        <div class="left-column pull-left">
                            <ul class="social-links clearfix">
                                <li><p>Follow Us:</p></li>
                                   <li><a href="https://www.twitter.com/"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https://www.facebook.com/"><i class="fab fa-facebook-square"></i></a></li>
                      
                        <li><a href="https://www.instagram.com/"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="https://www.youtube.com/"><i class="fab fa-youtube"></i></a></li>
                            </ul>
                        </div>
                        <div class="right-column pull-right">
                            <ul class="info-box clearfix">
                               
                                <li>
                                    <div class="icon-box"><i class="fas fa-phone"></i></div>
                                    <p>Call: <a href="tel:12345678910">123 4567 8910</a></p>
                                </li>
                                <li>
                                    <div class="icon-box"><i class="fas fa-envelope"></i></div>
                                    <p>Email: <a href="mailto:info@rugcleanbronx.com">info@rugcleanbronx.com</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header-lower -->
            <div class="header-lower">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <div class="shape" style="background-image: url(assets/images/shape/shape-1.png);"></div>
                            <figure class="logo"><a href="index.php"><img src="assets/images/logo/Header-logo.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></a></figure>
                        </div>
                        <div class="menu-area clearfix">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                    <ul class="navigation clearfix">
                                        <li>   <a href="index.php?area=<?php echo $area; ?>">Home</a>
                                           
                                        </li>
                                        <li class="dropdown"><a href="#">Area Rug</a>
                                            <ul>
                                                <li><a href="Area-Rug-Cleaning-Bronx.php?area=<?php echo $area; ?>">Area Rug Cleaning</a></li>
                                                <li><a href="Area-Rug-Repair-Bronx.php?area=<?php echo $area; ?>">Area Rug Repair</a></li>
                                                
                                            </ul>
                                         
                                        </li> 
                                        <li class="dropdown"><a href="#">Carpet</a>
                                            <ul>
                                                <li><a href="Carpet-Cleaning-Bronx.php?area=<?php echo $area; ?>">Carpet Cleaning</a></li>
                                                
                                                <li><a href="Carpet-Installation-Bronx.php?area=<?php echo $area; ?>">Carpet Installation</a></li>
                                            </ul>
                                        </li> 
                                        <li class="dropdown">
                                             <a href="#">Services</a>
                                            <ul>

                                             
                                       <li><a href="Upholstery-Cleaning-Bronx.php?area=<?php echo $area; ?>">Upholstery Cleaning</a></li>
                                                <li><a href="Water-Flood-Damage-Bronx.php?area=<?php echo $area; ?>">Water Flood Damage</a></li>
                                                <li><a href="Commercial-Cleaning-Bronx.php?area=<?php echo $area; ?>">Commercial Cleaning</a></li>
                                                <li><a href="Organic-Cleaning-Bronx.php?area=<?php echo $area; ?>">Organic Cleaning</a></li>
                                                 <li><a href="Allergy-Control-Bronx.php?area=<?php echo $area; ?>">Allergy Control</a></li>
                                                 <li><a href="Drapery-Cleaning-Bronx.php?area=<?php echo $area; ?>">Drapery Cleaning</a></li>
                                                <li><a href="Mattress-Cleaning-Bronx.php?area=<?php echo $area; ?>">Mattress Cleaning</a></li>
                                                 <li><a href="Bed-Bug-Treatment-Bronx.php?area=<?php echo $area; ?>">Bed Bug Treatment</a></li>
                                                <li><a href="Leather-Cleaning-Bronx.php?area=<?php echo $area; ?>">Leather Cleaning</a></li>
                                               
                                                <li><a href="Pet-Stain-Odor-Removal-Bronx.php?area=<?php echo $area; ?>">Pet Stain Odor Removal</a></li>
                                                <li><a href="Miscellaneous-Services-Bronx.php?area=<?php echo $area; ?>">Miscellaneous Services</a></li>
                                           
                                            </ul>
                                        </li> 
                                        <li > <a href="servicearea.php?area=<?php echo $area; ?>">Service Areas</a>
                                        </li>  
                                        <li><a href="offers.php?area=<?php echo $area; ?>">Offers</a></li> 
                                          <li><a href="blog.php?area=<?php echo $area; ?>">Blogs</a></li>
                                                <li><a href="contact.php?area=<?php echo $area; ?>" >Contact</a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="nav-right">
                           
                            <div class="btn-box"><a href="tel:123456789" class="theme-btn btn-one">Call Us</a></div>
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box">
                        <div class="logo-box">
                            <figure class="logo"><a href="index.php"><img src="assets/images/logo/Header-logo.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></a></figure>
                        </div>
                        <div class="menu-area clearfix">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                        
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href="index.php"><img src="assets/images/logo/Footer-logo.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>Bronx,New York, USA</li>
                        <li><a href="tel:+123 456 789">+123 456 789</a></li>
                        <li><a href="mailto:info@rugcleanbronx.com">info@rugcleanbronx.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href="https://www.twitter.com/"><span class="fab fa-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/"><span class="fab fa-facebook-square"></span></a></li>
                     
                        <li><a href="https://www.instagram.com/"><span class="fab fa-instagram"></span></a></li>
                        <li><a href="https://www.youtube.com/"><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->
