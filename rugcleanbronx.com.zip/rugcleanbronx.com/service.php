      <div class="col-lg-4 col-md-12 col-sm-12 sidebar-side">
                        <div class="service-sidebar p_relative d_block mr_20">
                            <div class="category-widget p_relative d_block pt_30 pr_40 pb_12 pl_40 b_radius_5 mb_50">
                                <h2 class="d_block fs_30 lh_40 mb_3">Our Services</h2>
                                <br>
                                <ul class="category-list clearfix">
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Area-Rug-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Area Rug Cleaning</a></li>
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Area-Rug-Repair-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock ">Area Rug Repair</a></li>
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Carpet-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Carpet Cleaning</a></li>
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Carpet-Installation-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Carpet Installation</a></li>
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Upholstery-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Upholstery Cleaning</a></li>
                                    <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Water-Flood-Damage-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Water Flood Damage</a></li>
                                     <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Commercial-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Commercial Cleaning</a></li>
                                      <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Organic-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Organic Cleaning</a></li>
                                       <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Allergy-Control-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Allergy Control</a></li>
                                        <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Drapery-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Drapery Cleaning</a></li>
                                         <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Mattress-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Mattress Cleaning</a></li>
                                          <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Bed-Bug-Treatment-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Bed Bug Treatment</a></li>
                                           <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Leather-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Leather Cleaning</a></li>
                                            <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Pet-Stain-Odor-Removal-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Pet Stain Odor Removal</a></li>
                                             <li class="p_relative d_block pt_20 pb_20 fs_16 lh_26 fw_medium"><a href="Miscellaneous-Services-Bronx.php?area=<?php echo $area; ?>" class="p_relative d_iblock">Miscellaneous Services</a></li>
                                </ul>
                            </div>
                            
                        </div>
                    </div>