<?php include 'header.php';?>
<style>
  p{
  
  }
  .row{
    padding-left: 40px;
  }
  .lg1{
    margin-top: 50px;
  }
   .Alpha {
    color:  #37614d;
    margin-top: 10px !important; 
  }
  a{
    color:  #183d2b;
  }
  a:hover{
    color:  #84b09b;
  }
  body{
    overflow-x: hidden;
  }
  p{
      line-height: 18px;
     margin-top: 6px !important; 
  }
</style>
        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Service Areas - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->
         <section>
<div class="row">
      <div class="col-lg-3 lg1" >
        <h2 class="Alpha">A</h2>
    <p><a href="index.php?area=allerton-10469/">Allerton</a></p>
    <!-- <p><a href="index.php?area=astor-row-10037/">Astor Row</a></p> -->
 
    <h2 class="Alpha">B</h2>   
    <p><a href="index.php?area=baychester-10469/">Baychester</a></p>
    <p><a href="index.php?area=bedford-park-10458/">Bedford Park</a></p>
    <p><a href="index.php?area=belmont-10456/">Belmont</a></p>

     <p><a href="index.php?area=bronx-river-10472/">Bronx River</a></p>
    <p><a href="index.php?area=bronxdale-10462/">Bronxdale</a></p>
    <p><a href="index.php?area=bruckner-10473/">Bruckner</a></p>

    <h2 class="Alpha">C</h2>
     <p><a href="index.php?area=castle-hill-10473/">Castle Hill</a></p>
    <!-- <p>Heights</p> -->
     <p><a href="index.php?area=central-riverdale-10471/">Central Riverdale</a></p>
    <p><a href="index.php?area=city-island-10464/">City Island</a></p>
    <p><a href="index.php?area=clason-point-10473/">Clason Point</a></p>
    <p><a href="index.php?area=co-op-city-10475/">Co-op City</a></p>
      
      <p><a href="index.php?area=concourse-village-10451/">Concourse Village</a></p>
    <p><a href="index.php?area=country-club-10465/">Country Club</a></p>
    <p><a href="index.php?area=crotona-park-east-10460/">Crotona Park East</a></p>

    <h2 class="Alpha">D</h2>
    <p><a href="index.php?area=downtown-bronx-10451/">Downtown Bronx</a></p>
    <!-- <p><a href="index.php?area=downtown-manhattan-10013/">Downtown Manhattan</a></p> -->
    <h2 class="Alpha">E</h2>
    <p><a href="index.php?area=east-morrisania-10451/">East Morrisania</a></p>
  
     

   
    <!-- <p>Heights</p> -->
      </div>
      <div class="col-lg-3 lg1" >

    <p><a href="index.php?area=eastchester-10475/">Eastchester</a></p>
    <p><a href="index.php?area=edenwald-10466/">Edenwald</a></p>
    <p><a href="index.php?area=edgewater-park-10465/">Edgewater Park</a></p>

    <h2 class="Alpha">F</h2>

     
    <p><a href="index.php?area=fieldston-10471/">Fieldston</a></p>
    
    <p><a href="index.php?area=fordham-10455/">Fordham</a></p>
    
    <h2>H</h2>
    <p><a href="index.php?area=highbridge-10452/">Highbridge</a></p>

     
    <p><a href="index.php?area=hunts-point-10474/">Hunts Point</a></p>
 
    
 
  <h2 class="Alpha">I</h2>
    <p><a href="index.php?area=indian-village-10461/">Indian Village</a></p>
    <h2 class="Alpha">K</h2>
    <p><a href="index.php?area=kingsbridge-10463/">Kingsbridge</a></p>
    <p><a href="index.php?area=kingsbridge-heights-10468/">Kingsbridge Heights</a></p>
  
     <h2 class="Alpha">L</h2>
    <p><a href="index.php?area=locust-point-10461/">Locust Point</a></p>
     <p><a href="index.php?area=longwood-10474/">Longwood</a></p>
    
     <h2 class="Alpha">M</h2>


    <p><a href="index.php?area=marble-hill-10463/">Marble Hill</a></p>
    <p><a href="index.php?area=melrose-10451/">Melrose</a></p>
    <p><a href="index.php?area=morris-heights-10453/">Morris Heights</a></p>
     <p><a href="index.php?area=morris-park-10461/">Morris Park</a></p>
     
      </div>
      <div class="col-lg-3 lg1" >
        
     <p><a href="index.php?area=morrisania-10451/">Morrisania</a></p>

    <p><a href="index.php?area=mott-haven-10451/">Mott Haven</a></p>
     <p><a href="index.php?area=mount-eden-10452/">Mount Eden</a></p>

    <p><a href="index.php?area=mount-hope-10457/">Mount Hope</a></p>



      <h2 class="Alpha">N</h2>
    <p><a href="index.php?area=north-new-york-10459/">North New York</a></p>
     <p><a href="index.php?area=north-riverdale-10471/">North Riverdale</a></p>
     <p><a href="index.php?area=norwood-10467/">Norwood</a></p>

     <h2 class="Alpha">O</h2>
     <p><a href="index.php?area=olinville-10467/">Olinville</a></p>
         

     <h2 class="Alpha">P</h2>
     <p><a href="index.php?area=parkchester-10462/">Parkchester</a></p>
         <p><a href="index.php?area=pelham-bay-10461/">Pelham Bay</a></p>

         <p><a href="index.php?area=pelham-gardens-10469/">Pelham Gardens</a></p>
         <p><a href="index.php?area=pelham-manor-10803/">Pelham Manor</a></p>

         <p><a href="index.php?area=pelham-parkway-10461/">Pelham Parkway</a></p>
         <p><a href="index.php?area=port-morris-10454/">Port Morris</a></p>
   
      <h2 class="Alpha">R</h2>
    <p><a href="index.php?area=riverdale-10471/">Riverdale</a></p>
    
       <h2 class="Alpha">S</h2>
       <p><a href="index.php?area=schuylerville-10461/">Schuylerville</a></p>
       <p><a href="index.php?area=silver-beach-10465/">Silver Beach</a></p>
       
          
      
     
      </div>
      <div class="col-lg-3 lg1" >
        <p><a href="index.php?area=soundview-10472/">Soundview</a></p>
        <p><a href="index.php?area=spencer-estates-10465/">Spencer Estates</a></p>
       <p><a href="index.php?area=spuyten-duyvil-10463/">Spuyten Duyvil / South Riverdale</a></p>
       
    <h2 class="Alpha">T</h2>
        <p><a href="index.php?area=throgs-neck-10465/">Throgs Neck</a></p>
       <p><a href="index.php?area=tremont-10457/">Tremont / East Tremont</a></p>
       
        <h2 class="Alpha">U</h2>
       <p><a href="index.php?area=university-heights-10453/">University Heights</a></p>
       
       <h2 class="Alpha">V</h2>
        <p><a href="index.php?area=van-cortlandt-village-10705/">Van Cortlandt Village</a></p>
        <p><a href="index.php?area=van-nest-10462/">Van Nest</a></p>
        <h2 class="Alpha">W</h2>
       <p><a href="index.php?area=wakefield-10466/">Wakefield</a></p>
       <p><a href="index.php?area=west-farms-10460/">West Farms</a></p>
       <p><a href="index.php?area=westchester-heights-10472/">Westchester Heights</a></p>
       <p><a href="index.php?area=williamsbridge-10469/">Williamsbridge</a></p>
       <p><a href="index.php?area=woodlawn-heights-10470/">Woodlawn / Woodlawn Heights</a></p>

          <h2 class="Alpha">Z</h2>
       <p><a href="index.php?area=zerega-10462/">Zerega</a></p>
       
       
      </div>
    </div>
</section>
<?php include 'footer.php';?>