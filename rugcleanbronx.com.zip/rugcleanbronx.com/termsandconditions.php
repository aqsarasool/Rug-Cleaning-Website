
<?php include 'header.php';?>
<style>
h3{
     padding-top:15px;
    padding-bottom:15px;
    font-size:24px;
}
</style>
        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute" ></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Terms and Conditions  - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- service-details -->
        <section class="service-details pt_140 pb_140">
            <div class="auto-container">
                <div class="row clearfix">
        
                    <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                        <div class="service-details-content p_relative d_block">
                            <div class="content-one p_relative d_block mb_90">
                                <h2 class="d_block fs_30 lh_40 fw_medium mb_25">Terms and Conditions  - <?php echo ucwords($area, "-"); ?></h2>
                              <p>Welcome to our Terms And Conditions page. Below you will find our basic Terms and Conditions.

For More Information please contact us or phone 123 456 789.</p>
<h3>
Cleanings:</h3>
<p>
We do not guarantee all stains, spots or spills to be removed completely however, we will do our very best to remove them. Some stains, spots or spills are set it due to neglect or lack of maintenance. With professional cleaning from us, rugcleanbronx.com you will always we satisfied with our service, if you aren’t, we will clean it again at no additional charge. Contact must be within 24 hours of the original service date. Any new services, even within the 24 hours will be charged. No refunds on cleaning.

For More Information please contact us or phone 123 456 789.</p>
<h3>
Repairs:</h3>
<p>

With the initial visit, the technician will explain the entire service from beginning to the end. Before this service is started the entire amount must be paid. Any service that we are hesitant to do but are still insisted on by the customer then we wave all warranties and guarantee, full amount will be due. No refunds on repairs.</p>
<h3>
Sales/Installations:
</h3>
<p>
All new sales, installation and rug pad are a Final Sale and there are no exchanges and no returns. They are custom ordered items and once an order is placed the manufacturer cannot stop the process. No refunds or exchanges on Sales/Installations (Carpets/Window Coverings/Rug Pads).

For More Information please contact us or phone 123 456 789.
</p>
<h3>
Refunds, Exchanges:
</h3>
<p>
For More Information on full Refunds And Exchanges please contact us at 123 456 789
</p>
<h3>
In conclusion:
</h3>
    <p>
For More Information on more Terms And Conditions please contact us at 123 456 789
</p></p>
                               
                            </div>
                         
                    
                     
                        </div>
                    </div>
    <?php include 'service.php';?>
                </div>
            </div>
        </section>
        <!-- service-details end -->

<?php include 'footer.php';?>