<?php include 'header.php';?>
        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute" ></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Our Blogs - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- sidebar-page-container -->
        <section class="sidebar-page-container p_relative blog-classic pt_140 pb_150">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                        <div class="blog-classic-content p_relative d_block mr_20">
                            <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                                <div class="inner-box p_relative d_block b_radius_5 bg_white mb_70">
                                    <figure class="image-box p_relative d_block theme_bg"><a ><img src="assets/images/InnerBlogs/1.jpg" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></a></figure>
                                    <div class="lower-content p_relative d_block pt_35">
                                      
                                        <h2 class="p_relative d_block fs_30 lh_40 mb_2 fw_medium"><a  class="d_iblock hov_color">Blog Heading</a></h2>
                                        <ul class="post-info p_relative d_block mb_15 clearfix">
                                            <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color"></a></li>
                                         
                                        </ul>
                                        <p class="fs_15 lh_26 mb_20">Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.</p>
                                       
                                    </div>
                                </div>
                            </div>
                            <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                                <div class="inner-box p_relative d_block b_radius_5 bg_white mb_70">
                                    <figure class="image-box p_relative d_block theme_bg"><a ><img src="assets/images/InnerBlogs/1.jpg" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></a></figure>
                                    <div class="lower-content p_relative d_block pt_35">
                                        
                                        <h2 class="p_relative d_block fs_30 lh_40 mb_2 fw_medium"><a  class="d_iblock hov_color"> Blog Heading</a></h2>
                                        <ul class="post-info p_relative d_block mb_15 clearfix">
                                            <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color"></a></li>
                                            
                                        </ul>
                                        <p class="fs_15 lh_26 mb_20">Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniamLorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.</p>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                                <div class="inner-box p_relative d_block b_radius_5 bg_white mb_70">
                                    <figure class="image-box p_relative d_block theme_bg"><a><img src="assets/images/InnerBlogs/1.jpg" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></a></figure>
                                    <div class="lower-content p_relative d_block pt_35">
                                       
                                        <h2 class="p_relative d_block fs_30 lh_40 mb_2 fw_medium"><a  class="d_iblock hov_color">Blog Heading</a></h2>
                                        <ul class="post-info p_relative d_block mb_15 clearfix">
                                            <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color"></a></li>
                                            
                                        </ul>
                                        <p class="fs_15 lh_26 mb_20">Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam.</p>
                                        
                                    </div>
                                </div>
                            </div>
                         
                         
                        </div>
                    </div>
                   <?php include 'service.php';?>
                </div>
            </div>
        </section>
        <!-- sidebar-page-container end -->

<?php include 'footer.php';?>