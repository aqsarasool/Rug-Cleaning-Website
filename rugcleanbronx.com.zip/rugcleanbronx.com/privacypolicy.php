
<?php include 'header.php';?>
<style>
h3{
     padding-top:15px;
    padding-bottom:15px;
    font-size:24px;
}
</style>
        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute" ></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Privacy Policy  - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- service-details -->
        <section class="service-details pt_140 pb_140">
            <div class="auto-container">
                <div class="row clearfix">
        
                    <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                        <div class="service-details-content p_relative d_block">
                            <div class="content-one p_relative d_block mb_90">
                                <h2 class="d_block fs_30 lh_40 fw_medium mb_25">Privacy Policy  - <?php echo ucwords($area, "-"); ?></h2>
                               <h3>
Introduction</h3>
<p>
This privacy statement discloses the privacy practices for the website rugcleanbronx.com. We are committed to protecting your privacy and encourage you to periodically review this page to be informed of how we protect the information you disclose to us.</p>
<h3>
Use of Personal Information</h3>
<p>

Any information you submit through rugcleanbronx.com web site will be held in the strictest confidence. In no way will your personal information ever be used without your consent. To ensure this, all forms on our web sites that send information to a database that may be used in the future, e.g. mailing lists, registration, etc., have check boxes where you specify whether or not you would like to receive information from us in the future. Forms used just to send e-mail, post messages, etc., do not include the option, but will never be used to send information. Be assured that we do not sell our name and address lists. If you choose to receive information from us, each message will also include instructions on how to “unsubscribe” from future mailings should you wish to cancel.

The only information we automatically collect is that related to the use of our web site. This information is anonymous and is gathered through our servers’ log files. These log files record generic information, such as the number of visits our web site receives, the types of browsers used and the number of files downloaded, but never personal information. This log file information allows us to create better content aimed at our viewer’s preferences.ount must be paid. Any service that we are hesitant to do but are still insisted on by the customer then we wave all warranties and guarantee, full amount will be due. No refunds on repairs.</p>
<h3>
Use of Cookies
</h3>
<p>
Some of our pages use a feature of your browser called a “cookie.” Cookies, by themselves, are not able to extract any personal information from you. This cookie automatically identifies your computer – but not you – to our servers when you visit our site. Unless you specifically tell us, abcarpetcleaners.com will never know who you are, even though we may assign your computer a cookie. Also, rugcleanbronx.com web site can only read cookies created by rugcleanbronx.com web site.

Cookies allow us to personalize our site for you and to provide you with information that fits your needs and desires. For instance, once you register your product online, a cookie is written to your computer so that you will not need to type information in the future to obtain support.
</p>
<h3>
Contact us
</h3>
<p>
Rug Clean Bronx knows that your privacy is very important to you. We welcome questions and comments regarding this policy, so feel free to contact us. Because technologies on the Internet change so quickly, AB Rug Cleaners reserves the right to modify its Privacy Statement from time to time 123 456 789.
</p>
                               
                            </div>
                         
                    
                     
                        </div>
                    </div>
                          <?php include 'service.php';?>
                </div>
            </div>
        </section>
        <!-- service-details end -->

<?php include 'footer.php';?>