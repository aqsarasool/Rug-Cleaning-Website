<?php include 'header.php';?>

        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute"></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Contact - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- contact-section -->
        <section class="contact-section p_relative pt_140 pb_150">
            <div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-5 col-md-12 col-sm-12 info-column">
                        <div class="info-inner p_relative d_block mr_30 b_radius_5 theme_bg pt_65 pr_50 pb_100 pl_70">
                            <div class="shape p_absolute" style="background-image: url(assets/images/shape/shape-39.png);"></div>
                            <h2 class="p_relative d_block fs_30 lh_40 color_white mb_30">Contact <br />Information</h2>
                            <ul class="info-list clearfix">
                                <li class="p_relative d_block pl_70 mb_25">
                                    <div class="icon-box p_absolute b_radius_5 bg_white theme_color centred fs_22 lh_50"><i class="fas fa-map-marker-alt"></i></div>
                                    <h3 class="fs_22 lh_32 fw_medium color_white mb_5">Office Location</h3>
                                    <p class="fs_15 lh_26 color_white"><a href="https://goo.gl/maps/WdkVhsYb7SAR5kf17" class="color_white" >Bronx, New York, USA</a></p>
                                </li>
                                <li class="p_relative d_block pl_70 mb_25">
                                    <div class="icon-box p_absolute b_radius_5 bg_white theme_color centred fs_22 lh_50"><i class="fas fa-envelope-open"></i></div>
                                    <h3 class="fs_22 lh_32 fw_medium color_white mb_5">Email Us</h3>
                                    <p class="fs_15 lh_26 color_white"><a href="mailto:info@rugcleanbronx.com" class="color_white">info@rugcleanbronx.com</a></p>
                                </li>
                                <li class="p_relative d_block pl_70">
                                    <div class="icon-box p_absolute b_radius_5 bg_white theme_color centred fs_22 lh_50"><i class="fas fa-phone"></i></div>
                                    <h3 class="fs_22 lh_32 fw_medium color_white mb_5">Call Us</h3>
                                    <p class="fs_15 lh_26 color_white"><a href="tel:123456789" class="color_white">+123 456 789</a></p>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12 col-sm-12 form-column">
                        <div class="form-inner">
                            <h2 class="p_relative d_block fs_30 lh_40 mb_30">Send Us A Message</h2>
                            <form method="post" action="#" id="contact-form" class="default-form"> 
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group mb_30">
                                        <input type="text" name="username" placeholder="Your Name" required="">
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 form-group mb_30">
                                        <input type="email" name="email" placeholder="Email Address" required="">
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group mb_30">
                                        <input type="text" name="phone" required="" placeholder="Phone Number">
                                    </div>
                                    <div class="col-lg-6 col-md-12 col-sm-12 form-group mb_30">
                                        <input type="text" name="subject" required="" placeholder="Subject">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group mb_30">
                                        <textarea name="message" placeholder="Your Message"></textarea>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn mr-0">
                                        <button class="theme-btn btn-one" type="submit" name="submit-form">Message</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact-section end -->


        <!-- google-map-section -->
        <section class="google-map-section p_relative pb_150">
            <div class="auto-container">
                <div class="map-inner">
                   
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d96573.46942750532!2d-73.84093399999999!3d40.851659999999995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c28b553a697cb1%3A0x556e43a78ff15c77!2sBronx%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1690801075486!5m2!1sen!2s" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    
                </div>
            </div>
        </section>
        <!-- google-map-section -->
<?php include 'footer.php';?>