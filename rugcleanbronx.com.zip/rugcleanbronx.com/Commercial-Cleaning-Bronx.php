
<?php include 'header.php';?>
        <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute" ></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Commercial Cleaning  - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->


        <!-- service-details -->
        <section class="service-details pt_140 pb_140">
            <div class="auto-container">
                <div class="row clearfix">
      
                    <div class="col-lg-8 col-md-12 col-sm-12 content-side">
                        <div class="service-details-content p_relative d_block">
                            <div class="content-one p_relative d_block mb_90">
                                <h2 class="d_block fs_30 lh_40 fw_medium mb_25">Commercial Cleaning  - <?php echo ucwords($area, "-"); ?></h2>
                                <p class="fs_15 lh_26 mb_25">Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit vo luptatem accusantium doloremque laudantium.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit vo luptatem accusantium doloremque laudantium.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit vo luptatem accusantium doloremque laudantium.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit vo luptatem accusantium doloremque laudantium.Lorem ipsum dolor sit amet consec tetur adipisicing sed do eiusmod tempor incididunt labore dolore magna aliqua enim minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit vo luptatem accusantium doloremque laudantium.</p>
                                  <div class="col-lg-10 col-md-12 col-sm-12 inner-column">
                            <div class="inner-content ml_40">
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6 col-sm-12 feature-block">
                                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                                            <div class="inner-box p_relative d_block pl_40 pt_40 pr_20 pb_30 tran_5 b_radius_5">
                                                <div class="icon-box p_relative d_iblock b_radius_10 fs_35 theme_color tran_5 mb_30 centred"><i class="icon-7"></i></div>
                                                <h3 class="d_block fs_22 lh_30 fw_medium">Cost Saving</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 feature-block">
                                        <div class="feature-block-two wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                                            <div class="inner-box p_relative d_block pl_40 pt_40 pr_20 pb_30 tran_5 b_radius_5">
                                                <div class="icon-box p_relative d_iblock b_radius_10 fs_35 theme_color tran_5 mb_30 centred"><i class="icon-5"></i></div>
                                                <h3 class="d_block fs_22 lh_30 fw_medium">Eco Friendly</h3>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                            </div>
                         
                    
                     
                        </div>
                    </div>
                       <?php include 'service.php';?>
                </div>
            </div>
        </section>
        <!-- service-details end -->

<?php include 'footer.php';?>