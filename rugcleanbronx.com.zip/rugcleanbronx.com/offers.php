
<?php include 'header.php';?>
  <!-- Page Title -->
        <section class="page-title p_relative pt_150 pb_180 centred" style="background-image: url(assets/images/breadcrumb/1.jpg);">
            <div class="pattern-layer p_absolute" ></div>
            <div class="auto-container">
                <div class="content-box">
                    <h1 class="d_block fs_70 lh_70 mb_20 color_white">Our Offers  - <?php echo ucwords($area, "-"); ?></h1>
                    <p class="d_block fs_20 lh_30 color_white">Rug Clean Bronx</p>
                </div>
            </div>
        </section>
        <!-- End Page Title -->
        <!-- news-section -->
        <section class="news-section p_relative blog-grid pt_140 pb_150">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="col-lg-6 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box p_relative d_block b_radius_5 b_shadow_7 bg_white mb_30">
                                <figure class="image-box p_relative d_block theme_bg"><img src="assets/images/InnerOffers/Area-Rug-Cleaning.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></figure>
                                <div class="lower-content p_relative d_block pl_40 pt_35 pr_30 pb_40">
                                   
                                    <h3 class="p_relative d_block fs_22 lh_28 mb_5 fw_medium"><a href="Area-Rug-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="d_iblock hov_color">Area Rug Cleaning Services</a></h3>
                                    <ul class="post-info p_relative d_block mb_15 clearfix">
                                        <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color">GET 20% OFF</a></li>
                                    
                                    </ul>
                                    <p class="fs_15 lh_26 mb_25">Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.</p>
                                    <div class="btn-box">
                                        <a href="tel:123456789" class="theme-btn btn-two">Call Us<i class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box p_relative d_block b_radius_5 b_shadow_7 bg_white mb_30">
                                <figure class="image-box p_relative d_block theme_bg"><img src="assets/images/InnerOffers/Area-Rug-Repair.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></figure>
                                <div class="lower-content p_relative d_block pl_40 pt_35 pr_30 pb_40">
                                    
                                    <h3 class="p_relative d_block fs_22 lh_28 mb_5 fw_medium"><a href="Area-Rug-Repair-Bronx.php?area=<?php echo $area; ?>" class="d_iblock hov_color">Area Rug Repair Services</a></h3>
                                    <ul class="post-info p_relative d_block mb_15 clearfix">
                                        <li class="p_relative d_iblock float_left fs_15 mr_25"><a class="fw_medium hov_color">GET 20% OFF</a></li>
                                        
                                    </ul>
                                    <p class="fs_15 lh_26 mb_25">Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.</p>
                                    <div class="btn-box">
                                        <a href="tel:123456789" class="theme-btn btn-two">Call Us<i class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box p_relative d_block b_radius_5 b_shadow_7 bg_white mb_30">
                                <figure class="image-box p_relative d_block theme_bg"><img src="assets/images/InnerOffers/Carpet-Cleaning.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></figure>
                                <div class="lower-content p_relative d_block pl_40 pt_35 pr_30 pb_40">
                                   
                                    <h3 class="p_relative d_block fs_22 lh_28 mb_5 fw_medium"><a href="Carpet-Cleaning-Bronx.php?area=<?php echo $area; ?>" class="d_iblock hov_color">Carpet Cleaning Services</a></h3>
                                    <ul class="post-info p_relative d_block mb_15 clearfix">
                                        <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color">GET 20% OFF</a></li>
                                        
                                    </ul>
                                    <p class="fs_15 lh_26 mb_25">Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.</p>
                                    <div class="btn-box">
                                        <a href="tel:123456789" class="theme-btn btn-two">Call Us <i class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 news-block">
                        <div class="news-block-one wow fadeInUp animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box p_relative d_block b_radius_5 b_shadow_7 bg_white mb_30">
                                <figure class="image-box p_relative d_block theme_bg"><img src="assets/images/InnerOffers/Water-Flood-Damage.png" alt="carpet cleaning in 
                        Bronx, carpet cleaner in Bronx, carpet cleaners in Bronx, carpet cleaners in Bronx,
                         drapery cleaners in Bronx, carpet cleaning in Bronx, mattress cleaning in Bronx, 
                        mattress cleaners in Bronx, commercial carpet cleaning, commercial carpet cleaners in Bronx
                        , Bronx rug cleaners, rug cleaning services in Bronx same day carpet cleaning, same day rug
                         cleaning"></figure>
                                <div class="lower-content p_relative d_block pl_40 pt_35 pr_30 pb_40">
                                    
                                    <h3 class="p_relative d_block fs_22 lh_28 mb_5 fw_medium"><a href="Water-Flood-Damage-Bronx.php?area=<?php echo $area; ?>" class="d_iblock hov_color">Water Flood Damage Services</a></h3>
                                    <ul class="post-info p_relative d_block mb_15 clearfix">
                                        <li class="p_relative d_iblock float_left fs_15 mr_25"><a  class="fw_medium hov_color">GET 20% OFF</a></li>
                                        
                                    </ul>
                                    <p class="fs_15 lh_26 mb_25">Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.Lorem ipsum dolor sit amet consec tetur adipisicing sed.</p>
                                    <div class="btn-box">
                                        <a href="tel:123456789" class="theme-btn btn-two">Call Us<i class="far fa-long-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                   
                </div>
              
            </div>
        </section>
        <!-- news-section end -->
<?php include 'footer.php';?>